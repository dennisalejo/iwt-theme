<?php get_header(); ?>
<div class="content">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) : the_post();
            the_title( '<h2><a href="' . get_permalink() . '">', '</a></h2>' );
            the_content();
        endwhile;
    else :
        echo '<p>No posts found.</p>';
    endif;
    ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>