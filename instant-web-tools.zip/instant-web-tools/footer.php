    <footer>
        <p>Built with <a href="https://instantwebtools.co">Instant Web Tools, LLC</a></p>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>