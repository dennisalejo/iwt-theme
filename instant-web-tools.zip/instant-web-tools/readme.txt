=== Instant Web Tools ===
Contributors: Dennis Alejo
Author URI: https://dennis.tips
Tags: minimal, lightweight, fast, SEO
Requires at least: 4.5
Tested up to: 6.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
A lightweight, minimal WordPress theme designed for lightning-fast loading speeds and SEO optimization.

== Installation ==
1. Upload the theme files to the `/wp-content/themes/instant-web-tools` directory.
2. Activate the theme through the 'Appearance > Themes' menu in WordPress.

== Changelog ==
= 1.0 =
* Initial release.

== Credits ==
* Designed by Dennis Alejo - https://dennis.tips
* Built with Instant Web Tools, LLC - https://instantwebtools.co