<aside>
    <?php if ( is_active_sidebar( 'primary-sidebar' ) ) : ?>
        <?php dynamic_sidebar( 'primary-sidebar' ); ?>
    <?php else : ?>
        <p>Add widgets to the sidebar through the WordPress admin.</p>
    <?php endif; ?>
</aside>