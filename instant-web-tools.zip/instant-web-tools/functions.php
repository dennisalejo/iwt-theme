<?php
// Theme setup
function instant_web_tools_setup() {
    // Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );
    // Let WordPress manage the document title.
    add_theme_support( 'title-tag' );
    // Add theme support for selective refresh for widgets.
    add_theme_support( 'customize-selective-refresh-widgets' );
}
add_action( 'after_setup_theme', 'instant_web_tools_setup' );

// Enqueue scripts and styles
function instant_web_tools_enqueue() {
    wp_enqueue_style( 'instant-web-tools-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'instant_web_tools_enqueue' );
?>